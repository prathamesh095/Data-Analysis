# Electric Vehicle Population Data

## Overview
This dataset contains information about electric vehicles registered in various locations. It provides insights into EV adoption, geographic distribution, vehicle types, and more.

## Column Descriptions

- **VIN (1-10)**: The first 10 characters of the Vehicle Identification Number (VIN), uniquely identifying each vehicle.
- **County**: The county where the vehicle is registered, useful for analyzing EV adoption at a county level.
- **City**: The city where the vehicle is registered, providing insights at a local level.
- **State**: The state where the vehicle is registered (e.g., "WA" for Washington).
- **Postal Code**: The ZIP code of the registered vehicle, aiding demographic and geographic analysis.
- **Model Year**: The manufacturing year of the vehicle, helping track the age of EVs on the road.
- **Make**: The vehicle manufacturer (e.g., Tesla, Chevrolet, BMW).
- **Model**: The specific model of the vehicle (e.g., Model S, Bolt EV, i3).
- **Electric Vehicle Type**:
  - **Battery Electric Vehicle (BEV)**: Fully electric, no gasoline engine.
  - **Plug-in Hybrid Electric Vehicle (PHEV)**: Contains both a battery-powered motor and a gasoline engine.
- **Clean Alternative Fuel Vehicle (CAFV) Eligibility**: Indicates if the vehicle qualifies as a Clean Alternative Fuel Vehicle based on government regulations.
- **Electric Range**: The estimated number of miles the vehicle can travel on a full charge.
- **Base MSRP**: The Manufacturer’s Suggested Retail Price (MSRP) of the vehicle, useful for price trend analysis.
- **Legislative District**: The district where the vehicle is registered, useful for policy and regulation tracking.
- **DOL Vehicle ID**: Unique identifier assigned to the vehicle by the Department of Licensing (DOL).
- **Vehicle Location**: Geographic coordinates (latitude and longitude) indicating where the vehicle is registered.
- **Electric Utility**: The name of the electricity provider for the registered location, useful for analyzing EV charging infrastructure.
- **2020 Census Tract**: A geographic identifier used in census data, aiding demographic analysis related to EV ownership.

## Purpose
This dataset is valuable for:
- Understanding the adoption trends of electric vehicles.
- Analyzing geographic distribution and infrastructure needs for EVs.
- Studying policy effectiveness in promoting electric vehicles.

## Usage
This data can be used in various analyses, including:
- EV market research.
- Government policy evaluation.
- Infrastructure planning for EV charging stations.
- Environmental impact studies.

